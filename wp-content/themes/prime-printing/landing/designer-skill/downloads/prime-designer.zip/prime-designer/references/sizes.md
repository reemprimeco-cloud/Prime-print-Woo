# Standard sizes (use only when the user didn't give dimensions — and say so)

| Product | Trim size | Bleed | Notes |
|---|---|---|---|
| Business card (Gulf/EU) | 85 × 55 mm | 3 mm | US: 3.5 × 2 in (89 × 51 mm) |
| Letterhead | A4 210 × 297 mm | 3 mm | 100–120 gsm uncoated |
| Envelope DL | 220 × 110 mm | 3 mm | Window optional; confirm flap side |
| Envelope C4 | 324 × 229 mm | 3 mm | Holds unfolded A4 |
| Flyer | A5 148 × 210 / A4 210 × 297 mm | 3 mm | 150–170 gsm gloss/matte |
| Brochure tri-fold | A4 open, panels 99/100/98 mm | 3 mm | Inside fold panel 1–2 mm narrower |
| Bi-fold | A4 → A5 | 3 mm | |
| Roll-up banner | 85 × 200 cm (also 100 × 200, 120 × 200) | top 2 cm, bottom 10–15 cm hidden in cassette | Keep key info between 60–180 cm height |
| Foam board | A2 / A1 / 70 × 100 cm | 3 mm | 5 mm board standard |
| Sticker / label | per request | 2–3 mm | Kiss-cut line as spot color |
| Poster | A3 / A2 / 50 × 70 cm | 3 mm | |

## Resolution by product
- Close-reading print (cards, flyers, boxes): 300 DPI
- Posters viewed at 1–2 m: 200–300 DPI
- Banners / roll-ups: 100–150 DPI at full size
