# Packaging reference

## Structures
| Type | Best for | Board |
|---|---|---|
| Reverse tuck-end (RTE) | Cosmetics, small products | 300–400 gsm SBS / Ivory |
| Straight tuck-end (STE) | Retail display | 300–400 gsm |
| Crash-lock bottom | Heavier items | 350–400 gsm |
| Mailer (roll-end) | E-commerce, subscription | E-flute corrugated |
| Rigid two-piece (lid & base) | Luxury, gifts, perfume | 1.5–2 mm greyboard wrapped in 120–157 gsm art paper |
| Magnetic closure | Premium gift sets | 1.5–2 mm greyboard + magnets |
| Drawer / sleeve | Chocolates, jewelry | Rigid tray + 350 gsm sleeve |
| Pillow box | Small favors | 300–350 gsm |
| Paper bag | Retail | 170–250 gsm art / kraft, rope or ribbon handles |

## Dimensions
Always give **internal** L × W × H. Board thickness adds to the external size (e.g. +1 mm per wall for 350 gsm, +3–4 mm for rigid).

## Finishes and when to use them
- **Matte lamination** — modern, fingerprint-prone on dark colors.
- **Soft-touch (velvet) lamination** — premium hand-feel; pairs with spot UV and foil.
- **Gloss lamination** — vivid colors, food and kids.
- **Spot UV** — highlight logo/pattern over matte; needs a separate 100% K spot layer.
- **Hot foil** (gold/silver/rose/holographic) — min line 0.3 mm, min text 8 pt; separate vector layer.
- **Emboss / deboss** — needs a die; avoid fine details under 0.5 mm.
- **Window patch** — PET film; keep 5 mm from folds.

## Dieline layers (deliver as separate spot colors)
- CUT — solid line, spot "Cut", 100% M
- CREASE — dashed line, spot "Crease", 100% C
- GLUE — hatched area, marked "no ink" if needed
- FOIL / SPOT UV / EMBOSS — each its own spot layer, overprint
- Bleed 3–5 mm beyond cut; no text within 3 mm of a crease.

## Cost sanity
Rigid + foil + emboss on <100 pcs is expensive. Offer: printed gold (Pantone 871 C) instead of foil, or a sticker seal on a plain rigid box.
